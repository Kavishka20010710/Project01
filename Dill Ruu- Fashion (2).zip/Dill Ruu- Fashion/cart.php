<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$cart_items = [];
$total = 0;
$wishlist_count = 0;

if (isset($pdo)) {
    $stmt = $pdo->prepare("SELECT c.id, c.product_id, c.price, c.quantity, p.image_path, p.stock 
                          FROM cart c JOIN products p ON c.product_id = p.id 
                          WHERE c.user_id = ?");
    $stmt->execute([$user_id]);
    $cart_items = $stmt->fetchAll();
    $total = array_sum(array_column($cart_items, 'price'));
}

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['remove'])) {
        $product_id = intval($_POST['product_id']);
        $stmt = $pdo->prepare("DELETE FROM cart WHERE user_id = ? AND product_id = ?");
        $stmt->execute([$user_id, $product_id]);
    } elseif (isset($_POST['update_quantity'])) {
        $cart_id = intval($_POST['cart_id']);
        $quantity = max(1, intval($_POST['quantity']));
        $stmt = $pdo->prepare("SELECT product_id, quantity AS current_quantity, price FROM cart WHERE id = ?");
        $stmt->execute([$cart_id]);
        $cart_item = $stmt->fetch();

        if ($cart_item) {
            $product_id = $cart_item['product_id'];
            $stmt = $pdo->prepare("SELECT stock FROM products WHERE id = ?");
            $stmt->execute([$product_id]);
            $product = $stmt->fetch();

            if ($product && $quantity <= $product['stock']) {
                $stmt = $pdo->prepare("UPDATE cart SET quantity = ? WHERE id = ?");
                $stmt->execute([$quantity, $cart_id]);
            } else {
                echo json_encode(['error' => 'Quantity exceeds available stock or is invalid.']);
                exit;
            }
        }
    }
    $cart_count = $pdo->query("SELECT COUNT(*) FROM cart WHERE user_id = $user_id")->fetchColumn();
    $wishlist_count = $pdo->query("SELECT COUNT(*) FROM wishlist WHERE user_id = $user_id")->fetchColumn();
    $new_total = array_sum(array_column($cart_items, 'price')); // Recalculate total
    echo json_encode(['cart_count' => $cart_count, 'wishlist_count' => $wishlist_count, 'total' => $new_total]);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart - Dill Ruu Fashion</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">Dill Ruu Fashion</div>
        <ul class="nav-links" id="nav-links">
            <li><a href="index.php#home" class="nav-link">Home</a></li>
            <li><a href="index.php#new-arrivals" class="nav-link">New Arrivals</a></li>
            <li><a href="all-products.php" class="nav-link">All Products</a></li>
            <li><a href="index.php#about" class="nav-link">About</a></li>
            <li><a href="index.php#contact" class="nav-link">Contact</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
                <li><a href="profile.php" class="nav-link">Profile</a></li>
                <li><a href="logout.php" class="nav-link">Logout</a></li>
            <?php else: ?>
                <li><a href="login.php" class="nav-link">Login</a></li>
                <li><a href="register.php" class="nav-link">Register</a></li>
            <?php endif; ?>
        </ul>
        <div class="search-bar">
            <input type="text" placeholder="Search products..." class="search-input" id="product-search">
            <button class="search-button"><i class="fas fa-search"></i></button>
        </div>
        <div class="nav-icons">
            <a href="wishlist.php" class="nav-icon" title="Wishlist">
                <i class="fas fa-heart"></i>
                <span class="icon-badge" id="wishlist-badge"><?php echo $wishlist_count; ?></span>
            </a>
            <a href="cart.php" class="nav-icon" title="Cart">
                <i class="fas fa-shopping-cart"></i>
                <span class="icon-badge" id="cart-badge"><?php echo count($cart_items); ?></span>
            </a>
        </div>
        <div class="menu-toggle" id="mobile-menu">
            <span class="bar"></span>
            <span class="bar"></span>
            <span class="bar"></span>
        </div>
    </nav>

    <section class="cart-section">
        <h2 class="section-title">Your Cart</h2>
        <?php if (empty($cart_items)): ?>
            <p class="empty-message">Your cart is empty. <a href="all-products.php">Shop now</a></p>
        <?php else: ?>
            <div class="cart-grid">
                <?php foreach ($cart_items as $item): ?>
                    <div class="cart-item" data-cart-id="<?php echo $item['id']; ?>">
                        <div class="cart-item-image">
                            <img src="<?php echo htmlspecialchars($item['image_path']); ?>" alt="<?php echo htmlspecialchars($item['product_name']); ?>" loading="lazy">
                        </div>
                        <div class="cart-item-details">
                            <h3 class="product-name"><?php echo htmlspecialchars($item['product_name']); ?></h3>
                            <p class="product-price">Rs.<?php echo number_format($item['price'], 2); ?></p>
                            <div class="quantity-controls">
                                <button class="quantity-btn decrement" data-cart-id="<?php echo $item['id']; ?>"><i class="fas fa-minus"></i></button>
                                <input type="number" class="quantity-input" value="<?php echo $item['quantity']; ?>" min="1" max="<?php echo $item['stock']; ?>" data-cart-id="<?php echo $item['id']; ?>">
                                <button class="quantity-btn increment" data-cart-id="<?php echo $item['id']; ?>"><i class="fas fa-plus"></i></button>
                            </div>
                            <?php if ($item['quantity'] > $item['stock']): ?>
                                <p class="stock-warning">Warning: Only <?php echo $item['stock']; ?> available. Please adjust quantity.</p>
                            <?php endif; ?>
                        </div>
                        <form method="POST" class="remove-form">
                            <input type="hidden" name="product_id" value="<?php echo $item['product_id']; ?>">
                            <button type="submit" name="remove" class="remove-btn"><i class="fas fa-trash"></i> Remove</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="cart-total">
                <h3>Total: Rs.<span id="cart-total"><?php echo number_format($total, 2); ?></span></h3>
                <a href="checkout.php" class="checkout-btn">Proceed to Checkout <i class="fas fa-arrow-right"></i></a>
            </div>
        <?php endif; ?>
    </section>

    <script src="script.js"></script>
</body>
</html>