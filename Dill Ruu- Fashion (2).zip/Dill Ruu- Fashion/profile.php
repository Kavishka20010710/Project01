<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT username, email, profile_picture FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = htmlspecialchars($_POST['username']);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $profile_picture = $user['profile_picture'];

    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png'];
        $file_ext = strtolower(pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION));
        if (in_array($file_ext, $allowed) && $_FILES['profile_picture']['size'] <= 2 * 1024 * 1024) {
            $new_name = uniqid() . '.' . $file_ext;
            move_uploaded_file($_FILES['profile_picture']['tmp_name'], "uploads/" . $new_name);
            $profile_picture = $new_name;
            if ($user['profile_picture'] !== 'default.jpg') {
                unlink("uploads/" . $user['profile_picture']);
            }
        }
    }

    $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, profile_picture = ? WHERE id = ?");
    $stmt->execute([$username, $email, $profile_picture, $user_id]);
    header("Location: profile.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Dill Ruu Fashion</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="profile-header">
                <img src="uploads/<?php echo htmlspecialchars($user['profile_picture']); ?>" alt="Profile Picture" class="profile-img">
                <h2 class="auth-title">Your Profile</h2>
                <p class="auth-subtitle">Manage your Dill Ruu Fashion account</p>
            </div>
            <form method="POST" enctype="multipart/form-data" class="auth-form" id="profile-form">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" name="username" id="username" value="<?php echo htmlspecialchars($user['username']); ?>" placeholder="Username" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" placeholder="Email" required>
                </div>
                <div class="form-group">
                    <label for="profile_picture">Update Profile Picture</label>
                    <input type="file" name="profile_picture" id="profile_picture" accept=".jpg,.jpeg,.png">
                </div>
                <button type="submit" class="auth-btn">Update Profile <i class="fas fa-save"></i></button>
            </form>
            <a href="index.php" class="back-btn">Back to Home</a>
            <a href="logout.php" class="logout-btn">Logout <i class="fas fa-sign-out-alt"></i></a>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>