<?php
require 'db.php';

$password = password_hash('adminpassword', PASSWORD_DEFAULT); // Change 'adminpassword' to your desired password
$stmt = $pdo->prepare("UPDATE users SET password = ? WHERE role = 'admin'");
$stmt->execute([$password]);

echo "Admin password updated successfully!";
?>