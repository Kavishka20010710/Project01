<?php
session_start();
require 'db.php';

$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

// Check stock for a product
if (isset($_GET['check_stock']) && isset($_GET['product_id']) && $user_id) {
    $product_id = intval($_GET['product_id']);
    $stmt = $pdo->prepare("SELECT stock FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch();
    if ($product) {
        echo json_encode(['stock' => $product['stock']]);
    } else {
        echo json_encode(['error' => 'Product not found']);
    }
    exit;
}

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $user_id) {
    $product_id = intval($_POST['product_id']);
    $price = floatval($_POST['price']);
    $quantity = isset($_POST['quantity']) ? max(1, intval($_POST['quantity'])) : 1;

    if ($_POST['action'] === 'add_to_cart') {
        $stmt = $pdo->prepare("INSERT INTO cart (user_id, product_id, price, quantity) VALUES (?, ?, ?, ?) 
                              ON DUPLICATE KEY UPDATE price = VALUES(price), quantity = VALUES(quantity)");
        $stmt->execute([$user_id, $product_id, $price, $quantity]);
    } elseif ($_POST['action'] === 'add_to_wishlist') {
        $stmt = $pdo->prepare("INSERT INTO wishlist (user_id, product_id) VALUES (?, ?) 
                              ON DUPLICATE KEY UPDATE product_id = product_id");
        $stmt->execute([$user_id, $product_id]);
    }
    $cart_count = $pdo->query("SELECT COUNT(*) FROM cart WHERE user_id = $user_id")->fetchColumn();
    $wishlist_count = $pdo->query("SELECT COUNT(*) FROM wishlist WHERE user_id = $user_id")->fetchColumn();
    echo json_encode(['cart_count' => $cart_count, 'wishlist_count' => $wishlist_count]);
    exit;
}

// Initialize category
$category = isset($_GET['category']) ? htmlspecialchars($_GET['category']) : 'all';

// Fetch products
$products = [];
$query = "SELECT p.*, COUNT(r.id) as rating_count, AVG(r.rating) as rating 
          FROM products p LEFT JOIN ratings r ON p.id = r.product_id";
if ($category !== 'all') {
    $query .= " WHERE p.category = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$category]);
} else {
    $query .= " WHERE 1=1";
    $stmt = $pdo->query($query);
}
$products = $stmt->fetchAll();

// Cart/wishlist counts
$cart_count = isset($user_id) ? $pdo->query("SELECT COUNT(*) FROM cart WHERE user_id = $user_id")->fetchColumn() : 0;
$wishlist_count = isset($user_id) ? $pdo->query("SELECT COUNT(*) FROM wishlist WHERE user_id = $user_id")->fetchColumn() : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Products - Dill Ruu Fashion</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">Dill Ruu Fashion</div>
        <ul class="nav-links" id="nav-links">
            <li><a href="index.php#home" class="nav-link">Home</a></li>
            <li><a href="index.php#new-arrivals" class="nav-link">New Arrivals</a></li>
            <li><a href="all-products.php" class="nav-link">All Products</a></li>
            <li><a href="index.php#about" class="nav-link">About</a></li>
            <li><a href="index.php#contact" class="nav-link">Contact</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
                <li><a href="profile.php" class="nav-link">Profile</a></li>
                <li><a href="logout.php" class="nav-link">Logout</a></li>
            <?php else: ?>
                <li><a href="login.php" class="nav-link">Login</a></li>
                <li><a href="register.php" class="nav-link">Register</a></li>
            <?php endif; ?>
        </ul>
        <div class="search-bar">
            <input type="text" placeholder="Search products..." class="search-input" id="product-search">
            <button class="search-button"><i class="fas fa-search"></i></button>
        </div>
        <div class="nav-icons">
            <a href="wishlist.php" class="nav-icon" title="Wishlist">
                <i class="fas fa-heart"></i>
                <span class="icon-badge" id="wishlist-badge"><?php echo $wishlist_count; ?></span>
            </a>
            <a href="cart.php" class="nav-icon" title="Cart">
                <i class="fas fa-shopping-cart"></i>
                <span class="icon-badge" id="cart-badge"><?php echo $cart_count; ?></span>
            </a>
        </div>
        <div class="menu-toggle" id="mobile-menu">
            <span class="bar"></span>
            <span class="bar"></span>
            <span class="bar"></span>
        </div>
    </nav>

    <section class="all-products-section">
        <div class="section-header">
            <h2 class="section-title">All Products</h2>
            <div class="product-filters">
                <div class="filter-group">
                    <select class="filter-select" onchange="window.location.href='?category=' + this.value">
                        <option value="all" <?php echo $category === 'all' ? 'selected' : ''; ?>>All Products</option>
                        <option value="men" <?php echo $category === 'men' ? 'selected' : ''; ?>>Men</option>
                        <option value="women" <?php echo $category === 'women' ? 'selected' : ''; ?>>Women</option>
                        <option value="kids" <?php echo $category === 'kids' ? 'selected' : ''; ?>>Kids</option>
                        <option value="bags" <?php echo $category === 'bags' ? 'selected' : ''; ?>>Bags</option>
                    </select>
                </div>
                <div class="search-group">
                    <input type="text" placeholder="Search..." class="search-input" id="product-search">
                    <button class="search-button"><i class="fas fa-search"></i></button>
                </div>
            </div>
        </div>
        <div class="product-grid" id="product-grid">
            <?php foreach ($products as $product): ?>
                <div class="product-card" data-product-id="<?php echo $product['id']; ?>" data-category="<?php echo htmlspecialchars($product['category']); ?>">
                    <div class="product-card-image">
                        <img src="<?php echo htmlspecialchars($product['image_path']); ?>" alt="<?php echo htmlspecialchars($product['product_name']); ?>" loading="lazy">
                        <button class="wishlist-btn"><i class="fas fa-heart"></i></button>
                        <button class="quick-view-btn"><i class="fas fa-eye"></i></button>
                    </div>
                    <h3 class="product-name"><?php echo htmlspecialchars($product['product_name']); ?></h3>
                    <p class="product-price">Rs.<?php echo number_format($product['price'], 2); ?></p>
                    <p class="product-stock"><?php echo $product['stock'] > 0 ? "Stock: {$product['stock']} Available" : "Out of Stock"; ?></p>
                    <div class="product-rating" data-rating="<?php echo htmlspecialchars($product['rating'] ?? '0'); ?>">
                        <span class="rating-stars"></span>
                        <span class="rating-count">(<?php echo isset($product['rating_count']) ? $product['rating_count'] : '0'; ?>)</span>
                    </div>
                    <form method="POST" class="cart-form" onsubmit="addToCart(event, this)">
                        <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                        <input type="hidden" name="price" value="<?php echo htmlspecialchars($product['price']); ?>">
                        <input type="number" name="quantity" value="1" min="1" max="<?php echo $product['stock']; ?>" class="quantity-input" <?php echo $product['stock'] <= 0 ? 'disabled' : ''; ?>>
                        <button type="submit" name="add_to_cart" class="add-to-cart-btn" <?php echo $product['stock'] <= 0 ? 'disabled' : ''; ?>><i class="fas fa-cart-plus"></i> Add to Cart</button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <div id="quick-view-modal" class="modal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <div class="modal-image"></div>
            <div class="modal-details">
                <h3 class="modal-title"></h3>
                <p class="modal-price"></p>
                <p class="modal-stock"></p>
                <div class="modal-rating"></div>
                <p class="modal-description"></p>
                <form method="POST" class="modal-cart-form" onsubmit="addToCart(event, this)">
                    <input type="hidden" name="product_id" id="modal-product-id">
                    <input type="hidden" name="price" id="modal-price">
                    <input type="number" name="quantity" value="1" min="1" id="modal-quantity" class="quantity-input">
                    <button type="submit" name="add_to_cart" class="add-to-cart-btn" id="modal-add-to-cart"><i class="fas fa-cart-plus"></i> Add to Cart</button>
                </form>
            </div>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>