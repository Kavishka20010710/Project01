// Toggle Mobile Menu
const mobileMenu = document.getElementById('mobile-menu');
const navLinks = document.getElementById('nav-links');
const navbar = document.querySelector('.navbar');

if (mobileMenu && navLinks) {
    mobileMenu.addEventListener('click', () => {
        mobileMenu.classList.toggle('active');
        navLinks.classList.toggle('active');
        if (navLinks.classList.contains('active')) {
            navLinks.style.animation = 'slideDown 0.3s ease';
        }
    });

    // Close Mobile Menu on Link Click
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', () => {
            if (navLinks.classList.contains('active')) {
                mobileMenu.classList.remove('active');
                navLinks.classList.remove('active');
            }
        });
    });
}

// Smooth Scrolling
document.querySelectorAll('.nav-link').forEach(anchor => {
    anchor.addEventListener('click', (e) => {
        e.preventDefault();
        const target = document.querySelector(anchor.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth' });
            if (navLinks && navLinks.classList.contains('active')) {
                navLinks.classList.remove('active');
                mobileMenu.classList.remove('active');
            }
        }
    });
});

// Navbar Scroll Effect
window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// Password Visibility Toggle
document.querySelectorAll('.form-group input[type="password"]').forEach(input => {
    const icon = input.nextElementSibling;
    if (icon && icon.classList.contains('input-icon')) {
        icon.addEventListener('click', () => {
            input.type = input.type === 'password' ? 'text' : 'password';
            icon.classList.toggle('fa-eye');
            icon.classList.toggle('fa-eye-slash');
        });
    }
});

// Form Validation
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return;

    form.addEventListener('submit', (e) => {
        let isValid = true;
        const username = form.querySelector('input[name="username"]');
        const email = form.querySelector('input[name="email"]');
        const password = form.querySelector('input[name="password"]');
        const file = form.querySelector('input[type="file"]');

        form.querySelectorAll('.form-error').forEach(error => error.style.display = 'none');

        if (username && (username.value.length < 3 || username.value.length > 50)) {
            showError(username, 'Username must be 3-50 characters.');
            isValid = false;
        }

        if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
            showError(email, 'Please enter a valid email.');
            isValid = false;
        }

        if (password && (password.value.length < 6 || !/[A-Z]/.test(password.value) || !/[0-9]/.test(password.value))) {
            showError(password, 'Password must be at least 6 characters with an uppercase letter and a number.');
            isValid = false;
        }

        if (file && file.files.length > 0) {
            const fileSize = file.files[0].size / 1024 / 1024; // MB
            const fileExt = file.files[0].name.split('.').pop().toLowerCase();
            if (fileSize > 2 || !['jpg', 'jpeg', 'png'].includes(fileExt)) {
                showError(file, 'Image must be JPG/PNG and under 2MB.');
                isValid = false;
            }
        }

        if (!isValid) e.preventDefault();
    });
}

function showError(input, message) {
    let error = input.nextElementSibling;
    if (!error || !error.classList.contains('form-error')) {
        error = document.createElement('span');
        error.classList.add('form-error');
        input.parentNode.insertBefore(error, input.nextSibling);
    }
    error.textContent = message;
    error.style.display = 'block';
}

// Product Filtering and Searching
const categoryFilter = document.querySelector('.filter-select');
const productSearch = document.getElementById('product-search');
const productGrid = document.getElementById('product-grid');
const searchButton = document.querySelector('.search-button');

function filterProducts() {
    if (!productGrid) return;

    const category = categoryFilter?.value || 'all';
    const searchQuery = productSearch?.value.toLowerCase() || '';

    productGrid.querySelectorAll('.product-card').forEach(card => {
        const productName = card.querySelector('.product-name').textContent.toLowerCase();
        const productCategory = card.dataset.category || 'all';

        const matchesCategory = category === 'all' || productCategory === category;
        const matchesSearch = productName.includes(searchQuery);

        card.style.display = (matchesCategory && matchesSearch) ? 'block' : 'none';
        if (matchesCategory && matchesSearch) {
            card.style.animation = 'fadeInUp 0.5s ease-out';
        }
    });
}

if (categoryFilter) categoryFilter.addEventListener('change', filterProducts);
if (productSearch) productSearch.addEventListener('input', filterProducts);
if (searchButton) searchButton.addEventListener('click', filterProducts);

document.addEventListener('DOMContentLoaded', filterProducts);

// Generate Star Ratings
function generateStars(ratingElement) {
    const rating = parseFloat(ratingElement.dataset.rating) || 0;
    const stars = Math.round(rating * 2) / 2;
    let starHtml = '';

    for (let i = 1; i <= 5; i++) {
        if (i <= stars) {
            starHtml += '<i class="fas fa-star"></i>';
        } else if (i - 0.5 === stars) {
            starHtml += '<i class="fas fa-star-half-alt"></i>';
        } else {
            starHtml += '<i class="far fa-star"></i>';
        }
    }
    ratingElement.querySelector('.rating-stars').innerHTML = starHtml;
}

document.querySelectorAll('.product-rating').forEach(generateStars);

// Cart and Wishlist
const cartBadge = document.querySelector('.nav-icon[title="Cart"] .icon-badge');
const wishlistBadge = document.querySelector('.nav-icon[title="Wishlist"] .icon-badge');
const loadingSpinner = document.createElement('div');
loadingSpinner.className = 'loading-spinner';
document.body.appendChild(loadingSpinner);

function updateBadge(badge, count) {
    if (badge) {
        badge.textContent = count > 0 ? count : '';
        badge.style.display = count > 0 ? 'inline-block' : 'none';
    }
}

function updateCartTotal(total) {
    const cartTotal = document.getElementById('cart-total');
    if (cartTotal) {
        cartTotal.textContent = numberFormat(total, 2);
    }
}

function numberFormat(number, decimals) {
    return number.toFixed(decimals).replace(/\d(?=(\d{3})+\.)/g, '$&,');
}

// Update Quantity via AJAX
function updateQuantity(cartId, quantity) {
    showLoading();
    fetch('cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `update_quantity=1&cart_id=${cartId}&quantity=${quantity}`
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.error) {
            alert(data.error);
            const input = document.querySelector(`.quantity-input[data-cart-id="${cartId}"]`);
            if (input) input.value = input.dataset.previousQuantity || 1;
            return;
        }
        updateBadge(cartBadge, data.cart_count);
        updateBadge(wishlistBadge, data.wishlist_count);
        updateCartTotal(data.total);
        const cartItem = document.querySelector(`.cart-item[data-cart-id="${cartId}"]`);
        if (cartItem) {
            const stock = parseInt(cartItem.querySelector('.quantity-input').max);
            const warning = cartItem.querySelector('.stock-warning');
            if (warning) warning.style.display = quantity > stock ? 'block' : 'none';
        }
    })
    .catch(error => {
        hideLoading();
        console.error('Error updating quantity:', error);
        alert('An error occurred while updating quantity. Please try again.');
    });
}

// Handle Quantity Changes
document.querySelectorAll('.quantity-btn').forEach(button => {
    button.addEventListener('click', (e) => {
        const cartId = button.dataset.cartId;
        const input = document.querySelector(`.quantity-input[data-cart-id="${cartId}"]`);
        if (!input) return;

        let quantity = parseInt(input.value) || 1;
        if (button.classList.contains('increment')) {
            quantity += 1;
        } else if (button.classList.contains('decrement')) {
            quantity = Math.max(1, quantity - 1);
        }

        const maxQuantity = parseInt(input.max);
        if (quantity > maxQuantity) {
            alert(`Maximum quantity available is ${maxQuantity}.`);
            quantity = maxQuantity;
        }

        input.value = quantity;
        input.dataset.previousQuantity = quantity;
        updateQuantity(cartId, quantity);
    });
});

document.querySelectorAll('.quantity-input').forEach(input => {
    input.addEventListener('change', (e) => {
        const cartId = input.dataset.cartId;
        let quantity = parseInt(input.value) || 1;
        const maxQuantity = parseInt(input.max);

        if (quantity < 1) {
            alert('Quantity must be at least 1.');
            quantity = 1;
        } else if (quantity > maxQuantity) {
            alert(`Maximum quantity available is ${maxQuantity}.`);
            quantity = maxQuantity;
        }

        input.value = quantity;
        input.dataset.previousQuantity = quantity;
        updateQuantity(cartId, quantity);
    });
});

// Add to Cart/Wishlist
window.isUserLoggedIn = document.body.dataset.userLoggedIn === 'true';

function addItem(action, productId, price, badge, button, quantity = 1) {
    if (!isUserLoggedIn) {
        alert('Please log in to add items to your cart or wishlist.');
        return;
    }

    showLoading();
    fetch(window.location.pathname + '?check_stock=1&product_id=' + encodeURIComponent(productId), {
        method: 'GET',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.error) {
            alert(data.error);
            return;
        }
        if (data.stock < quantity) {
            alert(`Sorry, only ${data.stock} items are available.`);
            return;
        }

        showLoading();
        fetch(window.location.pathname, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=${action}&product_id=${encodeURIComponent(productId)}&price=${price}&quantity=${quantity}`
        })
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
        .then(data => {
            hideLoading();
            updateBadge(badge, data[action === 'add_to_cart' ? 'cart_count' : 'wishlist_count']);
            button.classList.add('added');
            if (action === 'add_to_cart') {
                button.textContent = 'Added to Cart';
                setTimeout(() => window.location.href = 'cart.php', 500);
            } else {
                button.closest('.product-card').querySelector('.wishlist-btn').classList.add('active');
            }
            alert(`Added ${quantity} item(s) to your ${action === 'add_to_cart' ? 'cart' : 'wishlist'}!`);
        })
        .catch(error => {
            hideLoading();
            console.error('Error:', error);
            alert('An error occurred. Please try again.');
        });
    })
    .catch(error => {
        hideLoading();
        console.error('Error checking stock:', error);
        alert('An error occurred while checking stock. Please try again.');
    });
}

function addToCart(e, form) {
    e.preventDefault();
    const productId = form.querySelector('input[name="product_id"]').value;
    const price = form.querySelector('input[name="price"]').value;
    const quantity = parseInt(form.querySelector('input[name="quantity"]').value) || 1;
    addItem('add_to_cart', productId, price, cartBadge, form.querySelector('.add-to-cart-btn'), quantity);
}

document.querySelectorAll('.wishlist-btn').forEach(button => {
    button.addEventListener('click', (e) => {
        e.preventDefault();
        const productId = button.closest('.product-card').dataset.productId;
        addItem('add_to_wishlist', productId, 0, wishlistBadge, button);
    });
});

document.querySelectorAll('.quick-view-btn').forEach(button => {
    button.addEventListener('click', (e) => {
        e.preventDefault();
        const card = button.closest('.product-card');
        const productId = card.dataset.productId;
        showQuickView(productId);
    });
});

function showQuickView(productId) {
    showLoading();
    fetch(`all-products.php?quick_view=${productId}`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        const modal = document.getElementById('quick-view-modal');
        const modalImage = modal.querySelector('.modal-image');
        const modalTitle = modal.querySelector('.modal-title');
        const modalPrice = modal.querySelector('.modal-price');
        const modalStock = modal.querySelector('.modal-stock');
        const modalRating = modal.querySelector('.modal-rating');
        const modalDescription = modal.querySelector('.modal-description');
        const modalProductId = modal.querySelector('#modal-product-id');
        const modalPriceInput = modal.querySelector('#modal-price');
        const modalQuantity = modal.querySelector('#modal-quantity');
        const modalAddToCart = modal.querySelector('#modal-add-to-cart');

        modalImage.innerHTML = `<img src="${data.image_path}" alt="${data.product_name}">`;
        modalTitle.textContent = data.product_name;
        modalPrice.textContent = `Rs.${numberFormat(data.price, 2)}`;
        modalStock.textContent = data.stock > 0 ? `Stock: ${data.stock} Available` : 'Out of Stock';
        generateStars(modalRating);
        modalRating.dataset.rating = data.rating || '0';
        modalRating.querySelector('.rating-count').textContent = `(${data.rating_count || 0})`;
        modalDescription.textContent = data.description || 'No description available';
        modalProductId.value = data.id;
        modalPriceInput.value = data.price;
        modalQuantity.max = data.stock;
        modalQuantity.disabled = data.stock <= 0;
        modalAddToCart.disabled = data.stock <= 0;

        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    })
    .catch(error => {
        hideLoading();
        console.error('Error fetching quick view:', error);
        alert('An error occurred while loading the product. Please try again.');
    });
}

document.querySelector('.close-modal')?.addEventListener('click', () => {
    const modal = document.getElementById('quick-view-modal');
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
});

window.addEventListener('click', (e) => {
    const modal = document.getElementById('quick-view-modal');
    if (e.target === modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
});

// Initialize Badge Counts
updateBadge(cartBadge, window.cartCount || 0);
updateBadge(wishlistBadge, window.wishlistCount || 0);

// Apply Form Validation
['register-form', 'login-form', 'profile-form'].forEach(validateForm);

// Loading Spinner Functions
function showLoading() {
    loadingSpinner.style.display = 'block';
}

function hideLoading() {
    loadingSpinner.style.display = 'none';
}




// Admin Mobile Menu Toggle (Add to existing mobile menu logic)
const adminMobileMenu = document.querySelector('.admin-navbar #mobile-menu');
const adminNavLinks = document.querySelector('.admin-navbar #nav-links');

if (adminMobileMenu && adminNavLinks) {
    adminMobileMenu.addEventListener('click', () => {
        adminMobileMenu.classList.toggle('active');
        adminNavLinks.classList.toggle('active');
        if (adminNavLinks.classList.contains('active')) {
            adminNavLinks.style.animation = 'slideDown 0.3s ease';
        }
    });

    document.querySelectorAll('.admin-navbar .nav-link').forEach(link => {
        link.addEventListener('click', () => {
            if (adminNavLinks.classList.contains('active')) {
                adminMobileMenu.classList.remove('active');
                adminNavLinks.classList.remove('active');
            }
        });
    });
}

// Ensure loading spinner works with admin pages
function showLoading() {
    const spinner = document.querySelector('.loading-spinner');
    if (spinner) spinner.style.display = 'block';
}

function hideLoading() {
    const spinner = document.querySelector('.loading-spinner');
    if (spinner) spinner.style.display = 'none';
}

// Admin Dashboard Card Hover Animation
document.querySelectorAll('.dashboard-card').forEach(card => {
    card.addEventListener('mouseenter', () => {
        card.style.transform = 'translateY(-10px)';
        card.style.boxShadow = '0 10px 30px rgba(250, 37, 94, 0.2)';
    });
    card.addEventListener('mouseleave', () => {
        card.style.transform = 'translateY(0)';
        card.style.boxShadow = '0 6px 20px rgba(0, 0, 0, 0.1)';
    });
});

// Admin Form Submission Animation
document.querySelectorAll('.admin-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
        if (btn.type === 'submit') {
            showLoading();
            setTimeout(() => {
                hideLoading();
            }, 1000); // Simulate form submission delay
        }
    });
});

// Real-Time Updates Function
function updateDashboard() {
    showLoading();
    fetch('dashboard.php?update=1', {
        method: 'GET',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        document.querySelector('.dashboard-card:nth-child(1) p').textContent = data.product_count;
        document.querySelector('.dashboard-card:nth-child(2) p').textContent = data.order_count;
        document.querySelector('.dashboard-card:nth-child(3) p').textContent = data.user_count;
        document.querySelector('.analytics-value:nth-child(1)').textContent = 'Rs.' + numberFormat(data.total_revenue, 2);
        document.querySelector('.analytics-value:nth-child(2)').textContent = 'Rs.' + numberFormat(data.avg_order_value, 2);
        document.querySelector('.analytics-value:nth-child(3)').textContent = numberFormat(data.returning_percentage, 1) + '%';
        document.querySelector('.activity-list:nth-child(2)').innerHTML = data.recent_orders.map(order => `<li>Order #${order.id} - Rs.${numberFormat(order.total_amount, 2)} (<span class="order-status ${order.status}">${ucfirst(order.status)}</span>)</li>`).join('');
        document.querySelector('.activity-list:nth-child(3)').innerHTML = data.top_products.map(product => `<li>${product.product_name} - Sold: ${product.total_sold}</li>`).join('');
        const indicator = document.createElement('div');
        indicator.className = 'real-time-indicator';
        indicator.textContent = 'Updated just now';
        document.querySelector('.recent-activity').appendChild(indicator);
        setTimeout(() => indicator.remove(), 2000);
    })
    .catch(error => {
        hideLoading();
        console.error('Error updating dashboard:', error);
    });
}

setInterval(updateDashboard, 30000); // Update every 30 seconds
updateDashboard(); // Initial update