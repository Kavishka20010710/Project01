<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$cart_items = [];
$total = 0;

if (isset($pdo)) {
    $stmt = $pdo->prepare("SELECT c.product_id, c.price, c.quantity, p.image_path, p.stock 
                          FROM cart c JOIN products p ON c.product_id = p.id 
                          WHERE c.user_id = ?");
    $stmt->execute([$user_id]);
    $cart_items = $stmt->fetchAll();
    $total = array_sum(array_map(fn($item) => $item['price'] * $item['quantity'], $cart_items));

    // Check stock before proceeding
    $stock_error = false;
    foreach ($cart_items as $item) {
        if ($item['quantity'] > $item['stock']) {
            $stock_error = true;
            break;
        }
    }
}

// Handle order placement
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order']) && !$stock_error) {
    $shipping_address = htmlspecialchars($_POST['shipping_address']);
    $stmt = $pdo->prepare("INSERT INTO orders (user_id, total_amount, shipping_address) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $total, $shipping_address]);

    $order_id = $pdo->lastInsertId();
    foreach ($cart_items as $item) {
        $stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, price, quantity) VALUES (?, ?, ?, ?)");
        $stmt->execute([$order_id, $item['product_id'], $item['price'], $item['quantity']]);

        // Update stock
        $stmt = $pdo->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
        $stmt->execute([$item['quantity'], $item['product_id']]);
    }

    $stmt = $pdo->prepare("DELETE FROM cart WHERE user_id = ?");
    $stmt->execute([$user_id]);

    header("Location: orders.php?success=1");
    exit;
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order']) && $stock_error) {
    $error = "Cannot place order: Some items are out of stock or have insufficient quantity.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Dill Ruu Fashion</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">Dill Ruu Fashion</div>
        <ul class="nav-links" id="nav-links">
            <li><a href="index.php#home" class="nav-link">Home</a></li>
            <li><a href="index.php#new-arrivals" class="nav-link">New Arrivals</a></li>
            <li><a href="all-products.php" class="nav-link">All Products</a></li>
            <li><a href="index.php#about" class="nav-link">About</a></li>
            <li><a href="index.php#contact" class="nav-link">Contact</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
                <li><a href="profile.php" class="nav-link">Profile</a></li>
                <li><a href="logout.php" class="nav-link">Logout</a></li>
            <?php else: ?>
                <li><a href="login.php" class="nav-link">Login</a></li>
                <li><a href="register.php" class="nav-link">Register</a></li>
            <?php endif; ?>
        </ul>
        <div class="search-bar">
            <input type="text" placeholder="Search products..." class="search-input" id="product-search">
            <button class="search-button"><i class="fas fa-search"></i></button>
        </div>
        <div class="nav-icons">
            <a href="wishlist.php" class="nav-icon" title="Wishlist">
                <i class="fas fa-heart"></i>
                <span class="icon-badge" id="wishlist-badge"><?php echo $wishlist_count ?? 0; ?></span>
            </a>
            <a href="cart.php" class="nav-icon" title="Cart">
                <i class="fas fa-shopping-cart"></i>
                <span class="icon-badge" id="cart-badge"><?php echo count($cart_items); ?></span>
            </a>
        </div>
        <div class="menu-toggle" id="mobile-menu">
            <span class="bar"></span>
            <span class="bar"></span>
            <span class="bar"></span>
        </div>
    </nav>

    <section class="checkout-section">
        <h2 class="section-title">Checkout</h2>
        <?php if (empty($cart_items)): ?>
            <p class="empty-message">Your cart is empty. <a href="all-products.php">Shop now</a></p>
        <?php elseif ($stock_error): ?>
            <p class="auth-error"><?php echo $error; ?> <a href="cart.php">Return to Cart</a></p>
        <?php else: ?>
            <div class="checkout-grid">
                <div class="cart-items">
                    <h3>Your Items</h3>
                    <?php foreach ($cart_items as $item): ?>
                        <div class="cart-item">
                            <div class="cart-item-image">
                                <img src="<?php echo htmlspecialchars($item['image_path']); ?>" alt="<?php echo htmlspecialchars($item['product_name']); ?>" loading="lazy">
                            </div>
                            <div class="cart-item-details">
                                <h3 class="product-name"><?php echo htmlspecialchars($item['product_name']); ?></h3>
                                <p class="product-price">Rs.<?php echo number_format($item['price'] * $item['quantity'], 2); ?></p>
                                <p>Quantity: <?php echo $item['quantity']; ?></p>
                                <p>Stock Available: <?php echo $item['stock']; ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="shipping-form">
                    <h3>Shipping & Payment</h3>
                    <form method="POST">
                        <div class="form-group">
                            <label for="shipping_address">Shipping Address</label>
                            <input type="text" name="shipping_address" id="shipping_address" placeholder="Enter your shipping address" required>
                        </div>
                        <button type="submit" name="place_order" class="checkout-btn">Place Order <i class="fas fa-check"></i></button>
                    </form>
                    <?php if (isset($_GET['success']) && $_GET['success'] == 1): ?>
                        <p class="success-message">Order placed successfully! Check your <a href="orders.php">order history</a>.</p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="cart-total">
                <h3>Total: Rs.<span id="cart-total"><?php echo number_format($total, 2); ?></span></h3>
            </div>
        <?php endif; ?>
    </section>

    <script src="script.js"></script>
</body>
</html>