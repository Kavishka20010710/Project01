<?php
session_start();
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = htmlspecialchars($_POST['username']);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $profile_picture = 'default.jpg';

    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png'];
        $file_ext = strtolower(pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION));
        if (in_array($file_ext, $allowed) && $_FILES['profile_picture']['size'] <= 2 * 1024 * 1024) {
            $new_name = uniqid() . '.' . $file_ext;
            move_uploaded_file($_FILES['profile_picture']['tmp_name'], "uploads/" . $new_name);
            $profile_picture = $new_name;
        } else {
            $error = "Invalid image file. Use JPG/PNG, max 2MB.";
        }
    }

    if (!isset($error)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role, profile_picture) VALUES (?, ?, ?, 'customer', ?)");
            $stmt->execute([$username, $email, $password, $profile_picture]);
            $_SESSION['user_id'] = $pdo->lastInsertId();
            $_SESSION['role'] = 'customer';
            header("Location: profile.php");
            exit;
        } catch (PDOException $e) {
            $error = "Registration failed: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Dill Ruu Fashion</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <h2 class="auth-title">Create Your Account</h2>
            <p class="auth-subtitle">Join the Dill Ruu Fashion community</p>
            <?php if (isset($error)): ?>
                <p class="auth-error"><?php echo $error; ?></p>
            <?php endif; ?>
            <form method="POST" enctype="multipart/form-data" class="auth-form" id="register-form">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" name="username" id="username" placeholder="Username" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" placeholder="Email" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" name="password" id="password" placeholder="Password" required>
                    <i class="fas fa-eye input-icon" id="toggle-password"></i>
                </div>
                <div class="form-group">
                    <label for="profile_picture">Profile Picture (optional)</label>
                    <input type="file" name="profile_picture" id="profile_picture" accept=".jpg,.jpeg,.png">
                </div>
                <button type="submit" class="auth-btn">Register <i class="fas fa-user-plus"></i></button>
                <p class="auth-link">Already have an account? <a href="login.php">Login</a></p>
            </form>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>