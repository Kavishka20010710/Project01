<?php
session_start();
require 'db.php';

$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

// Check stock for a product
if (isset($_GET['check_stock']) && isset($_GET['product_id']) && $user_id) {
    $product_id = intval($_GET['product_id']);
    $stmt = $pdo->prepare("SELECT stock FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch();
    if ($product) {
        echo json_encode(['stock' => $product['stock']]);
    } else {
        echo json_encode(['error' => 'Product not found']);
    }
    exit;
}

// Handle POST actions

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $user_id) {
    $product_id = intval($_POST['product_id']);
    $price = floatval($_POST['price']);
    $quantity = isset($_POST['quantity']) ? max(1, intval($_POST['quantity'])) : 1;

    if ($_POST['action'] === 'add_to_cart') {
        $stmt = $pdo->prepare("INSERT INTO cart (user_id, product_id, price, quantity) VALUES (?, ?, ?, ?) 
                              ON DUPLICATE KEY UPDATE price = VALUES(price), quantity = VALUES(quantity)");
        $stmt->execute([$user_id, $product_id, $price, $quantity]);
    } elseif ($_POST['action'] === 'add_to_wishlist') {
        $stmt = $pdo->prepare("INSERT INTO wishlist (user_id, product_id) VALUES (?, ?) 
                              ON DUPLICATE KEY UPDATE product_id = product_id");
        $stmt->execute([$user_id, $product_id]);
    }
    $cart_count = $pdo->query("SELECT COUNT(*) FROM cart WHERE user_id = $user_id")->fetchColumn();
    $wishlist_count = $pdo->query("SELECT COUNT(*) FROM wishlist WHERE user_id = $user_id")->fetchColumn();
    echo json_encode(['cart_count' => $cart_count, 'wishlist_count' => $wishlist_count]);
    exit;
}

// Dynamic content
$welcomeMessage = "Welcome to Dill Ruu Fashion";
$tagline = "Unleash Your Style with Exclusive Trends";

// Fetch new arrivals
$new_arrivals = [];
if (isset($pdo)) {
    $query = "SELECT p.*, COUNT(r.id) as rating_count, AVG(r.rating) as rating 
              FROM products p LEFT JOIN ratings r ON p.id = r.product_id 
              ORDER BY p.created_at DESC LIMIT 4";
    $stmt = $pdo->query($query);
    $new_arrivals = $stmt->fetchAll();
}

// Cart/wishlist counts
$cart_count = isset($user_id) ? $pdo->query("SELECT COUNT(*) FROM cart WHERE user_id = $user_id")->fetchColumn() : 0;
$wishlist_count = isset($user_id) ? $pdo->query("SELECT COUNT(*) FROM wishlist WHERE user_id = $user_id")->fetchColumn() : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dill Ruu Fashion</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">Dill Ruu Fashion</div>
        <ul class="nav-links" id="nav-links">
            <li><a href="#home" class="nav-link">Home</a></li>
            <li><a href="#new-arrivals" class="nav-link">New Arrivals</a></li>
            <li><a href="all-products.php" class="nav-link">All Products</a></li>
            <li><a href="#about" class="nav-link">About</a></li>
            <li><a href="#contact" class="nav-link">Contact</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
                <li><a href="profile.php" class="nav-link">Profile</a></li>
                <li><a href="logout.php" class="nav-link">Logout</a></li>
            <?php else: ?>
                <li><a href="login.php" class="nav-link">Login</a></li>
                <li><a href="register.php" class="nav-link">Register</a></li>
            <?php endif; ?>
        </ul>
        <div class="search-bar">
            <input type="text" placeholder="Search products..." class="search-input" id="product-search">
            <button class="search-button"><i class="fas fa-search"></i></button>
        </div>
        <div class="nav-icons">
            <a href="wishlist.php" class="nav-icon" title="Wishlist">
                <i class="fas fa-heart"></i>
                <span class="icon-badge" id="wishlist-badge"><?php echo $wishlist_count; ?></span>
            </a>
            <a href="cart.php" class="nav-icon" title="Cart">
                <i class="fas fa-shopping-cart"></i>
                <span class="icon-badge" id="cart-badge"><?php echo $cart_count; ?></span>
            </a>
        </div>
        <div class="menu-toggle" id="mobile-menu">
            <span class="bar"></span>
            <span class="bar"></span>
            <span class="bar"></span>
        </div>
    </nav>

    <section class="hero-section" id="home">
        <div class="hero-overlay"></div>
        <div class="hero-content">
            <h1 class="hero-title"><?php echo htmlspecialchars($welcomeMessage); ?></h1>
            <p class="hero-subtitle"><?php echo htmlspecialchars($tagline); ?></p>
            <a href="#new-arrivals" class="hero-btn">Shop Now</a>
        </div>
        <div class="hero-image">
            <img src="assets\new1.jpg" alt="Fashion Collection" loading="lazy">
        </div>
    </section>

    <section class="new-arrivals-section" id="new-arrivals">
        <div class="section-header">
            <h2 class="section-title">New Arrivals</h2>
            <a href="all-products.php" class="see-all-btn">See All</a>
        </div>
        <div class="product-grid">
            <?php foreach ($new_arrivals as $product): ?>
                <div class="product-card" data-product-id="<?php echo $product['id']; ?>" data-category="<?php echo htmlspecialchars($product['category']); ?>">
                    <div class="product-card-image">
                        <img src="assets\gettyimages-182790712-612x612.jpg"<?php echo htmlspecialchars($product['image_path']); ?>" alt="<?php echo htmlspecialchars($product['product_name']); ?>" loading="lazy">
                        <button class="wishlist-btn"><i class="fas fa-heart"></i></button>
                        <button class="quick-view-btn"><i class="fas fa-eye"></i></button>
                    </div>
                    <h3 class="product-name"><?php echo htmlspecialchars($product['product_name']); ?></h3>
                    <p class="product-price">Rs.<?php echo number_format($product['price'], 2); ?></p>
                    <p class="product-stock"><?php echo $product['stock'] > 0 ? "Stock: {$product['stock']} Available" : "Out of Stock"; ?></p>
                    <div class="product-rating" data-rating="<?php echo htmlspecialchars($product['rating'] ?? '0'); ?>">
                        <span class="rating-stars"></span>
                        <span class="rating-count">(<?php echo isset($product['rating_count']) ? $product['rating_count'] : '0'; ?>)</span>
                    </div>
                    <form method="POST" class="cart-form" onsubmit="addToCart(event, this)">
                        <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                        <input type="hidden" name="price" value="<?php echo htmlspecialchars($product['price']); ?>">
                        <input type="number" name="quantity" value="1" min="1" max="<?php echo $product['stock']; ?>" class="quantity-input" <?php echo $product['stock'] <= 0 ? 'disabled' : ''; ?>>
                        <button type="submit" name="add_to_cart" class="add-to-cart-btn" <?php echo $product['stock'] <= 0 ? 'disabled' : ''; ?>><i class="fas fa-cart-plus"></i> Add to Cart</button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="promos-section">
        <div class="promo-grid">
            <div class="promo-card">
                <div class="promo-image">
                    <img src="assets\category1.jpeg" alt="Explore Our Mens Collection" class="promo-img" loading="lazy">
                </div>
                <div class="promo-content">
                    <h3 class="promo-title">Explore Our Mens Collection</h3>
                    <a href="all-products.php?category=men" class="shop-now-btn">Shop Now</a>
                </div>
            </div>
            <div class="promo-card">
                <div class="promo-image">
                    <img src="assets\product3.jpg" alt="Explore Our Women Collection" class="promo-img" loading="lazy">
                </div>
                <div class="promo-content">
                    <h3 class="promo-title">Explore Our Women Collection</h3>
                    <a href="all-products.php?category=women" class="shop-now-btn">Shop Now</a>
                </div>
            </div>
            <div class="promo-card">
                <div class="promo-image">
                    <img src="assets\category3.jpeg" alt="Explore Our Kids Collection" class="promo-img" loading="lazy">
                </div>
                <div class="promo-content">
                    <h3 class="promo-title">Explore Our Kids Collection</h3>
                    <a href="all-products.php?category=kids" class="shop-now-btn">Shop Now</a>
                </div>
            </div>
        </div>
    </section>

    <section class="about-section" id="about">
        <div class="about-container">
            <h2 class="section-title">About Us</h2>
            <div class="about-content">
                <div class="about-text">
                    <p class="about-description">At Dill Ruu Fashion, we weave innovation with elegance, crafting sustainable trends that empower your unique style. Our dedication to quality and creativity sets us apart in the world of fashion.</p>
                    <a href="#" class="learn-more-btn">Learn More</a>
                </div>
                <div class="about-image">
                    <img src="assets/story 1.jpg" alt="Our Story" class="about-img" loading="lazy">
                </div>
            </div>
        </div>
    </section>

    <section class="contact-section" id="contact">
        <div class="contact-container">
            <h2 class="section-title">Get in Touch</h2>
            <div class="contact-grid">
                <div class="contact-form">
                    <form action="#" method="POST" class="contact-form-group">
                        <div class="form-field">
                            <input type="text" name="name" placeholder="Your Name" required>
                        </div>
                        <div class="form-field">
                            <input type="email" name="email" placeholder="Your Email" required>
                        </div>
                        <div class="form-field">
                            <textarea name="message" placeholder="Your Message" rows="4" required></textarea>
                        </div>
                        <button type="submit" class="contact-btn">Send Message</button>
                    </form>
                </div>
                <div class="contact-info">
                    <div class="info-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <p class="info-text">
                            <a href="https://www.google.com/maps/search/?api=1&query=123+Fashion+Street,+Colombo,+Sri+Lanka" target="_blank">123 Fashion Street, Colombo, Sri Lanka</a>
                        </p>

                    </div>
                    <div class="info-item">
                        <i class="fas fa-phone"></i>
                        <p class="info-text">+94 724959062</p>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-envelope"></i>
                        <p class="info-text">info@dillruufashion.com</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div id="quick-view-modal" class="modal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <div class="modal-image"></div>
            <div class="modal-details">
                <h3 class="modal-title"></h3>
                <p class="modal-price"></p>
                <p class="modal-stock"></p>
                <div class="modal-rating"></div>
                <p class="modal-description"></p>
                <form method="POST" class="modal-cart-form" onsubmit="addToCart(event, this)">
                    <input type="hidden" name="product_id" id="modal-product-id">
                    <input type="hidden" name="price" id="modal-price">
                    <input type="number" name="quantity" value="1" min="1" id="modal-quantity" class="quantity-input">
                    <button type="submit" name="add_to_cart" class="add-to-cart-btn" id="modal-add-to-cart"><i class="fas fa-cart-plus"></i> Add to Cart</button>
                </form>
            </div>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>
