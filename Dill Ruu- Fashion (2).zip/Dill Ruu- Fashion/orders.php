<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$orders = [];
if (isset($pdo)) {
    $stmt = $pdo->prepare("SELECT o.id, o.order_date, o.total_amount, o.status, o.shipping_address 
                          FROM orders o WHERE o.user_id = ? ORDER BY o.order_date DESC");
    $stmt->execute([$user_id]);
    $orders = $stmt->fetchAll();
    $wishlist_count = $pdo->query("SELECT COUNT(*) FROM wishlist WHERE user_id = $user_id")->fetchColumn();
    $cart_count = $pdo->query("SELECT COUNT(*) FROM cart WHERE user_id = $user_id")->fetchColumn();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History - Dill Ruu Fashion</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">Dill Ruu Fashion</div>
        <ul class="nav-links" id="nav-links">
            <li><a href="index.php#home" class="nav-link">Home</a></li>
            <li><a href="index.php#new-arrivals" class="nav-link">New Arrivals</a></li>
            <li><a href="all-products.php" class="nav-link">All Products</a></li>
            <li><a href="index.php#about" class="nav-link">About</a></li>
            <li><a href="index.php#contact" class="nav-link">Contact</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
                <li><a href="profile.php" class="nav-link">Profile</a></li>
                <li><a href="logout.php" class="nav-link">Logout</a></li>
            <?php else: ?>
                <li><a href="login.php" class="nav-link">Login</a></li>
                <li><a href="register.php" class="nav-link">Register</a></li>
            <?php endif; ?>
        </ul>
        <div class="search-bar">
            <input type="text" placeholder="Search products..." class="search-input" id="product-search">
            <button class="search-button"><i class="fas fa-search"></i></button>
        </div>
        <div class="nav-icons">
            <a href="wishlist.php" class="nav-icon" title="Wishlist">
                <i class="fas fa-heart"></i>
                <span class="icon-badge" id="wishlist-badge"><?php echo $wishlist_count; ?></span>
            </a>
            <a href="cart.php" class="nav-icon" title="Cart">
                <i class="fas fa-shopping-cart"></i>
                <span class="icon-badge" id="cart-badge"><?php echo $cart_count; ?></span>
            </a>
        </div>
        <div class="menu-toggle" id="mobile-menu">
            <span class="bar"></span>
            <span class="bar"></span>
            <span class="bar"></span>
        </div>
    </nav>

    <section class="orders-section">
        <h2 class="section-title">Order History</h2>
        <?php if (empty($orders)): ?>
            <p class="empty-message">You have no orders yet. <a href="all-products.php">Shop now</a></p>
        <?php else: ?>
            <div class="orders-grid">
                <?php foreach ($orders as $order): ?>
                    <div class="order-item">
                        <h3>Order #<?php echo $order['id']; ?></h3>
                        <p>Date: <?php echo (new DateTime($order['order_date']))->format('F d, Y'); ?></p>
                        <p>Total: Rs.<?php echo number_format($order['total_amount'], 2); ?></p>
                        <p>Status: <span class="order-status <?php echo strtolower($order['status']); ?>"><?php echo ucfirst($order['status']); ?></span></p>
                        <p>Shipping Address: <?php echo htmlspecialchars($order['shipping_address']); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <script src="script.js"></script>
</body>
</html>