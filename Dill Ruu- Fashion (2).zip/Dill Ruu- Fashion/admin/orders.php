<?php
session_start();
require '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Pagination and search
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 10;
$search = isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '';

$offset = ($page - 1) * $limit;

$query = "SELECT o.id, o.order_date, o.total_amount, o.status, o.shipping_address, u.username 
          FROM orders o JOIN users u ON o.user_id = u.id 
          WHERE o.id LIKE ? OR u.username LIKE ? OR o.status LIKE ?";
$stmt = $pdo->prepare($query);
$stmt->execute(["%$search%", "%$search%", "%$search%"]);
$total_orders = $stmt->rowCount();
$total_pages = ceil($total_orders / $limit);

$query .= " ORDER BY o.order_date DESC LIMIT ? OFFSET ?";
$stmt = $pdo->prepare($query);
$stmt->execute(["%$search%", "%$search%", "%$search%", $limit, $offset]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle status updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $order_id = intval($_POST['order_id']);
    $status = htmlspecialchars($_POST['status']);
    $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->execute([$status, $order_id]);
    header("Location: orders.php?page=$page&search=" . urlencode($search));
    exit;
}

// Export function (already defined in dashboard.php)
if (isset($_GET['export']) && $_GET['export'] === 'orders') {
    $orders_data = $pdo->query("SELECT id, order_date, total_amount, status, shipping_address, u.username 
                               FROM orders o JOIN users u ON o.user_id = u.id")->fetchAll(PDO::FETCH_ASSOC);
    exportToCSV($orders_data, ['ID', 'Order Date', 'Total Amount', 'Status', 'Shipping Address', 'Customer'], 'orders');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders Management - Dill Ruu Fashion</title>
    <link rel="stylesheet" href="../styles.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
</head>
<body>
    <nav class="admin-navbar">
        <div class="logo">Dill Ruu Fashion Admin</div>
        <ul class="nav-links" id="admin-nav-links">
            <li><a href="dashboard.php" class="nav-link">Dashboard</a></li>
            <li><a href="products.php" class="nav-link">Products</a></li>
            <li><a href="orders.php" class="nav-link">Orders</a></li>
            <li><a href="users.php" class="nav-link">Users</a></li>
            <li><a href="../logout.php" class="nav-link logout">Logout <i class="fas fa-sign-out-alt"></i></a></li>
        </ul>
        <div class="menu-toggle" id="admin-mobile-menu">
            <span class="bar"></span>
            <span class="bar"></span>
            <span class="bar"></span>
        </div>
    </nav>

    <section class="admin-section">
        <h2 class="section-title">Orders Management</h2>
        <div class="admin-controls">
            <form method="GET" class="search-form">
                <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search orders..." class="search-input">
                <button type="submit" class="admin-btn"><i class="fas fa-search"></i> Search</button>
            </form>
            <a href="?export=orders" class="admin-btn export-btn"><i class="fas fa-download"></i> Export Orders</a>
        </div>
        <div class="orders-list">
            <?php if (empty($orders)): ?>
                <p class="empty-message">No orders found.</p>
            <?php else: ?>
                <?php foreach ($orders as $order): ?>
                    <div class="order-item">
                        <h3>Order #<?php echo $order['id']; ?></h3>
                        <p>Customer: <?php echo htmlspecialchars($order['username']); ?></p>
                        <p>Date: <?php echo (new DateTime($order['order_date']))->format('F d, Y'); ?></p>
                        <p>Total: Rs.<?php echo number_format($order['total_amount'], 2); ?></p>
                        <p>Status: 
                            <form method="POST" class="status-form">
                                <select name="status" required>
                                    <option value="pending" <?php echo $order['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="processing" <?php echo $order['status'] === 'processing' ? 'selected' : ''; ?>>Processing</option>
                                    <option value="shipped" <?php echo $order['status'] === 'shipped' ? 'selected' : ''; ?>>Shipped</option>
                                    <option value="delivered" <?php echo $order['status'] === 'delivered' ? 'selected' : ''; ?>>Delivered</option>
                                    <option value="cancelled" <?php echo $order['status'] === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                </select>
                                <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                <button type="submit" name="update_status" class="admin-btn update-btn"><i class="fas fa-sync"></i> Update</button>
                            </form>
                        </p>
                        <p>Shipping Address: <?php echo htmlspecialchars($order['shipping_address']); ?></p>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <div class="pagination">
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>" class="pagination-link <?php echo $page === $i ? 'active' : ''; ?>">
                    <?php echo $i; ?>
                </a>
            <?php endfor; ?>
        </div>
    </section>

    <script src="../script.js"></script>
</body>
</html>