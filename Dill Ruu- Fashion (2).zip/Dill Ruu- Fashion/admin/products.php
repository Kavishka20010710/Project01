<?php
session_start();
require '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Pagination and search
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 10;
$search = isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '';

$offset = ($page - 1) * $limit;

$query = "SELECT * FROM products WHERE product_name LIKE ? OR category LIKE ?";
$stmt = $pdo->prepare($query);
$stmt->execute(["%$search%", "%$search%"]);
$total_products = $stmt->rowCount();
$total_pages = ceil($total_products / $limit);

$query .= " LIMIT ? OFFSET ?";
$stmt = $pdo->prepare($query);
$stmt->execute(["%$search%", "%$search%", $limit, $offset]);
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) {
        $product_name = htmlspecialchars($_POST['product_name']);
        $price = floatval($_POST['price']);
        $category = htmlspecialchars($_POST['category']);
        $description = htmlspecialchars($_POST['description']);
        $stock = intval($_POST['stock']);
        $rating = floatval($_POST['rating']);
        $image_path = 'uploads/default.jpg';

        if (isset($_FILES['image_path']) && $_FILES['image_path']['error'] == 0) {
            $allowed = ['jpg', 'jpeg', 'png'];
            $file_ext = strtolower(pathinfo($_FILES['image_path']['name'], PATHINFO_EXTENSION));
            if (in_array($file_ext, $allowed) && $_FILES['image_path']['size'] <= 2 * 1024 * 1024) {
                $new_name = uniqid() . '.' . $file_ext;
                move_uploaded_file($_FILES['image_path']['tmp_name'], "../uploads/" . $new_name);
                $image_path = "uploads/" . $new_name;
            } else {
                $error = "Invalid image file. Use JPG/PNG, max 2MB.";
            }
        }

        if (!isset($error)) {
            $stmt = $pdo->prepare("INSERT INTO products (product_name, price, image_path, category, description, stock, rating) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$product_name, $price, $image_path, $category, $description, $stock, $rating]);
            header("Location: products.php?page=$page&search=" . urlencode($search));
            exit;
        }
    } elseif (isset($_POST['update'])) {
        $id = intval($_POST['id']);
        $product_name = htmlspecialchars($_POST['product_name']);
        $price = floatval($_POST['price']);
        $category = htmlspecialchars($_POST['category']);
        $description = htmlspecialchars($_POST['description']);
        $stock = intval($_POST['stock']);
        $rating = floatval($_POST['rating']);
        $image_path = $_POST['current_image'];

        if (isset($_FILES['image_path']) && $_FILES['image_path']['error'] == 0) {
            $allowed = ['jpg', 'jpeg', 'png'];
            $file_ext = strtolower(pathinfo($_FILES['image_path']['name'], PATHINFO_EXTENSION));
            if (in_array($file_ext, $allowed) && $_FILES['image_path']['size'] <= 2 * 1024 * 1024) {
                $new_name = uniqid() . '.' . $file_ext;
                move_uploaded_file($_FILES['image_path']['tmp_name'], "../uploads/" . $new_name);
                $image_path = "uploads/" . $new_name;
                $old_product = $pdo->prepare("SELECT image_path FROM products WHERE id = ?");
                $old_product->execute([$id]);
                $old_image = $old_product->fetchColumn();
                if ($old_image && $old_image !== 'uploads/default.jpg' && file_exists("../" . $old_image)) {
                    unlink("../" . $old_image);
                }
            } else {
                $error = "Invalid image file. Use JPG/PNG, max 2MB.";
            }
        }

        if (!isset($error)) {
            $stmt = $pdo->prepare("UPDATE products SET product_name = ?, price = ?, image_path = ?, category = ?, description = ?, stock = ?, rating = ? WHERE id = ?");
            $stmt->execute([$product_name, $price, $image_path, $category, $description, $stock, $rating, $id]);
            header("Location: products.php?page=$page&search=" . urlencode($search));
            exit;
        }
    } elseif (isset($_POST['delete'])) {
        $id = intval($_POST['id']);
        $product = $pdo->prepare("SELECT image_path FROM products WHERE id = ?");
        $product->execute([$id]);
        $image_path = $product->fetchColumn();
        if ($image_path && $image_path !== 'uploads/default.jpg' && file_exists("../" . $image_path)) {
            unlink("../" . $image_path);
        }
        $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$id]);
        header("Location: products.php?page=$page&search=" . urlencode($search));
        exit;
    }
}

// Export function (already defined in dashboard.php)
if (isset($_GET['export']) && $_GET['export'] === 'products') {
    $products_data = $pdo->query("SELECT id, product_name, price, category, description, stock, rating FROM products")->fetchAll(PDO::FETCH_ASSOC);
    exportToCSV($products_data, ['ID', 'Product Name', 'Price', 'Category', 'Description', 'Stock', 'Rating'], 'products');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products Management - Dill Ruu Fashion</title>
    <link rel="stylesheet" href="../styles.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
</head>
<body>
    <nav class="admin-navbar">
        <div class="logo">Dill Ruu Fashion Admin</div>
        <ul class="nav-links" id="admin-nav-links">
            <li><a href="dashboard.php" class="nav-link">Dashboard</a></li>
            <li><a href="products.php" class="nav-link">Products</a></li>
            <li><a href="orders.php" class="nav-link">Orders</a></li>
            <li><a href="users.php" class="nav-link">Users</a></li>
            <li><a href="../logout.php" class="nav-link logout">Logout <i class="fas fa-sign-out-alt"></i></a></li>
        </ul>
        <div class="menu-toggle" id="admin-mobile-menu">
            <span class="bar"></span>
            <span class="bar"></span>
            <span class="bar"></span>
        </div>
    </nav>

    <section class="admin-section">
        <h2 class="section-title">Products Management</h2>
        <div class="admin-controls">
            <form method="GET" class="search-form">
                <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search products..." class="search-input">
                <button type="submit" class="admin-btn"><i class="fas fa-search"></i> Search</button>
            </form>
            <a href="?export=products" class="admin-btn export-btn"><i class="fas fa-download"></i> Export Products</a>
        </div>
        <div class="admin-grid">
            <div class="admin-card">
                <h3>Add New Product</h3>
                <?php if (isset($error)): ?>
                    <p class="auth-error"><?php echo $error; ?></p>
                <?php endif; ?>
                <form method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="product_name">Product Name</label>
                        <input type="text" name="product_name" id="product_name" placeholder="Product Name" required>
                    </div>
                    <div class="form-group">
                        <label for="price">Price (Rs.)</label>
                        <input type="number" name="price" id="price" placeholder="Price (Rs.)" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label for="category">Category</label>
                        <select name="category" id="category" required>
                            <option value="men">Men</option>
                            <option value="women">Women</option>
                            <option value="kids">Kids</option>
                            <option value="bags">Bags</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="rating">Rating (0.0-5.0)</label>
                        <input type="number" name="rating" id="rating" placeholder="Rating (0.0-5.0)" step="0.1" min="0" max="5" required>
                    </div>
                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea name="description" id="description" placeholder="Description" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="stock">Stock Quantity</label>
                        <input type="number" name="stock" id="stock" placeholder="Stock Quantity" required>
                    </div>
                    <div class="form-group">
                        <label for="image_path">Product Image</label>
                        <input type="file" name="image_path" id="image_path" accept=".jpg,.jpeg,.png">
                    </div>
                    <button type="submit" name="add" class="admin-btn add-btn"><i class="fas fa-plus"></i> Add Product</button>
                </form>
            </div>

            <div class="admin-card">
                <h3>Existing Products</h3>
                <div class="products-list">
                    <?php foreach ($products as $product): ?>
                        <div class="product-item">
                            <img src="../<?php echo htmlspecialchars($product['image_path']); ?>" alt="<?php echo htmlspecialchars($product['product_name']); ?>" class="product-img">
                            <div class="product-details">
                                <h4><?php echo htmlspecialchars($product['product_name']); ?></h4>
                                <p>Price: Rs.<?php echo number_format($product['price'], 2); ?></p>
                                <p>Category: <?php echo htmlspecialchars($product['category']); ?></p>
                                <p>Stock: <?php echo $product['stock']; ?></p>
                                <p>Rating: <?php echo number_format($product['rating'], 1); ?>/5</p>
                            </div>
                            <form method="POST" enctype="multipart/form-data" class="edit-form">
                                <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
                                <input type="hidden" name="current_image" value="<?php echo $product['image_path']; ?>">
                                <input type="text" name="product_name" value="<?php echo htmlspecialchars($product['product_name']); ?>" required>
                                <input type="number" name="price" value="<?php echo $product['price']; ?>" step="0.01" required>
                                <select name="category" required>
                                    <option value="men" <?php echo $product['category'] === 'men' ? 'selected' : ''; ?>>Men</option>
                                    <option value="women" <?php echo $product['category'] === 'women' ? 'selected' : ''; ?>>Women</option>
                                    <option value="kids" <?php echo $product['category'] === 'kids' ? 'selected' : ''; ?>>Kids</option>
                                    <option value="bags" <?php echo $product['category'] === 'bags' ? 'selected' : ''; ?>>Bags</option>
                                </select>
                                <input type="number" name="rating" value="<?php echo $product['rating']; ?>" step="0.1" min="0" max="5" required>
                                <textarea name="description" required><?php echo htmlspecialchars($product['description']); ?></textarea>
                                <input type="number" name="stock" value="<?php echo $product['stock']; ?>" required>
                                <input type="file" name="image_path" accept=".jpg,.jpeg,.png">
                                <button type="submit" name="update" class="admin-btn update-btn"><i class="fas fa-save"></i> Update</button>
                            </form>
                            <form method="POST" class="delete-form">
                                <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
                                <button type="submit" name="delete" class="admin-btn delete-btn" onclick="return confirm('Are you sure you want to delete this product?')"><i class="fas fa-trash"></i> Delete</button>
                            </form>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="pagination">
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>" class="pagination-link <?php echo $page === $i ? 'active' : ''; ?>">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
    </section>

    <script src="../script.js"></script>
</body>
</html>