<?php
session_start();

//admin login

if ($user['role'] === 'admin') {
    $_SESSION['role'] = 'admin';
    header("Location: admin/dashboard.php");
    exit;
}