<?php
session_start();
require '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Pagination and search
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 10;
$search = isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '';

$offset = ($page - 1) * $limit;

$query = "SELECT * FROM users WHERE role = 'customer' AND (username LIKE ? OR email LIKE ?)";
$stmt = $pdo->prepare($query);
$stmt->execute(["%$search%", "%$search%"]);
$total_users = $stmt->rowCount();
$total_pages = ceil($total_users / $limit);

$query .= " LIMIT ? OFFSET ?";
$stmt = $pdo->prepare($query);
$stmt->execute(["%$search%", "%$search%", $limit, $offset]);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update'])) {
        $id = intval($_POST['id']);
        $username = htmlspecialchars($_POST['username']);
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        $profile_picture = $_POST['current_image'];

        if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
            $allowed = ['jpg', 'jpeg', 'png'];
            $file_ext = strtolower(pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION));
            if (in_array($file_ext, $allowed) && $_FILES['profile_picture']['size'] <= 2 * 1024 * 1024) {
                $new_name = uniqid() . '.' . $file_ext;
                move_uploaded_file($_FILES['profile_picture']['tmp_name'], "../uploads/" . $new_name);
                $profile_picture = $new_name;
                $old_user = $pdo->prepare("SELECT profile_picture FROM users WHERE id = ?");
                $old_user->execute([$id]);
                $old_image = $old_user->fetchColumn();
                if ($old_image && $old_image !== 'default.jpg' && file_exists("../uploads/" . $old_image)) {
                    unlink("../uploads/" . $old_image);
                }
            } else {
                $error = "Invalid image file. Use JPG/PNG, max 2MB.";
            }
        }

        if (!isset($error)) {
            $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, profile_picture = ? WHERE id = ?");
            $stmt->execute([$username, $email, $profile_picture, $id]);
            header("Location: users.php?page=$page&search=" . urlencode($search));
            exit;
        }
    } elseif (isset($_POST['delete'])) {
        $id = intval($_POST['id']);
        $user = $pdo->prepare("SELECT profile_picture FROM users WHERE id = ?");
        $user->execute([$id]);
        $profile_picture = $user->fetchColumn();
        if ($profile_picture && $profile_picture !== 'default.jpg' && file_exists("../uploads/" . $profile_picture)) {
            unlink("../uploads/" . $profile_picture);
        }
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$id]);
        header("Location: users.php?page=$page&search=" . urlencode($search));
        exit;
    }
}

// Export function (already defined in dashboard.php)
if (isset($_GET['export']) && $_GET['export'] === 'users') {
    $users_data = $pdo->query("SELECT id, username, email, profile_picture FROM users WHERE role = 'customer'")->fetchAll(PDO::FETCH_ASSOC);
    exportToCSV($users_data, ['ID', 'Username', 'Email', 'Profile Picture'], 'users');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users Management - Dill Ruu Fashion</title>
    <link rel="stylesheet" href="../styles.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
</head>
<body>
    <nav class="admin-navbar">
        <div class="logo">Dill Ruu Fashion Admin</div>
        <ul class="nav-links" id="admin-nav-links">
            <li><a href="dashboard.php" class="nav-link">Dashboard</a></li>
            <li><a href="products.php" class="nav-link">Products</a></li>
            <li><a href="orders.php" class="nav-link">Orders</a></li>
            <li><a href="users.php" class="nav-link">Users</a></li>
            <li><a href="../logout.php" class="nav-link logout">Logout <i class="fas fa-sign-out-alt"></i></a></li>
        </ul>
        <div class="menu-toggle" id="admin-mobile-menu">
            <span class="bar"></span>
            <span class="bar"></span>
            <span class="bar"></span>
        </div>
    </nav>

    <section class="admin-section">
        <h2 class="section-title">Users Management</h2>
        <div class="admin-controls">
            <form method="GET" class="search-form">
                <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search users..." class="search-input">
                <button type="submit" class="admin-btn"><i class="fas fa-search"></i> Search</button>
            </form>
            <a href="?export=users" class="admin-btn export-btn"><i class="fas fa-download"></i> Export Users</a>
        </div>
        <div class="users-list">
            <?php if (isset($error)): ?>
                <p class="auth-error"><?php echo $error; ?></p>
            <?php endif; ?>
            <?php if (empty($users)): ?>
                <p class="empty-message">No customers found.</p>
            <?php else: ?>
                <?php foreach ($users as $user): ?>
                    <div class="user-item">
                        <img src="../uploads/<?php echo htmlspecialchars($user['profile_picture']); ?>" alt="<?php echo htmlspecialchars($user['username']); ?>" class="user-img">
                        <div class="user-details">
                            <h3><?php echo htmlspecialchars($user['username']); ?></h3>
                            <p>Email: <?php echo htmlspecialchars($user['email']); ?></p>
                        </div>
                        <form method="POST" enctype="multipart/form-data" class="edit-form">
                            <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                            <input type="hidden" name="current_image" value="<?php echo $user['profile_picture']; ?>">
                            <input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                            <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                            <input type="file" name="profile_picture" accept=".jpg,.jpeg,.png">
                            <button type="submit" name="update" class="admin-btn update-btn"><i class="fas fa-save"></i> Update</button>
                        </form>
                        <form method="POST" class="delete-form">
                            <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                            <button type="submit" name="delete" class="admin-btn delete-btn" onclick="return confirm('Are you sure you want to delete this user?')"><i class="fas fa-trash"></i> Delete</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <div class="pagination">
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>" class="pagination-link <?php echo $page === $i ? 'active' : ''; ?>">
                    <?php echo $i; ?>
                </a>
            <?php endfor; ?>
        </div>
    </section>

    <script src="../script.js"></script>
</body>
</html>