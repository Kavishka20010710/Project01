<?php
session_start();
require '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Fetch dashboard metrics
$product_count = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$order_count = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$user_count = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn();

// Fetch total revenue and average order value
$total_revenue = $pdo->query("SELECT SUM(total_amount) FROM orders")->fetchColumn() ?: 0;
$avg_order_value = $order_count > 0 ? $total_revenue / $order_count : 0;

// Fetch analytics data (last 30 days)
$last_30_days = date('Y-m-d', strtotime('-30 days'));
$sales_stmt = $pdo->prepare("SELECT DATE(order_date) as date, SUM(total_amount) as total 
                           FROM orders WHERE order_date >= ? GROUP BY DATE(order_date)");
$sales_stmt->execute([$last_30_days]);
$sales_data = $sales_stmt->fetchAll(PDO::FETCH_ASSOC);

$user_growth_stmt = $pdo->prepare("SELECT DATE(created_at) as date, COUNT(*) as count 
                                 FROM users WHERE role = 'customer' AND created_at >= ? GROUP BY DATE(created_at)");
$user_growth_stmt->execute([$last_30_days]);
$user_growth = $user_growth_stmt->fetchAll(PDO::FETCH_ASSOC);

$category_distribution = $pdo->query("SELECT category, COUNT(*) as count FROM products GROUP BY category")->fetchAll(PDO::FETCH_ASSOC);

// Top-selling products
$top_products = $pdo->query("SELECT p.product_name, SUM(oi.quantity) as total_sold 
                           FROM products p JOIN order_items oi ON p.id = oi.product_id 
                           GROUP BY p.id ORDER BY total_sold DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

// Customer retention (corrected query)
$returning_customers_stmt = $pdo->query("SELECT COUNT(*) as returning 
                                       FROM (SELECT user_id FROM orders GROUP BY user_id HAVING COUNT(*) > 1) as returning_users");
$returning_customers = $returning_customers_stmt->fetchColumn() ?: 0;
$total_customers = $user_count;
$returning_percentage = $total_customers > 0 ? ($returning_customers / $total_customers) * 100 : 0;

// Fetch recent data
$recent_products = $pdo->query("SELECT product_name, price, image_path FROM products ORDER BY created_at DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
$recent_orders = $pdo->query("SELECT id, order_date, total_amount, status FROM orders ORDER BY order_date DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
$recent_users = $pdo->query("SELECT username, email FROM users WHERE role = 'customer' ORDER BY created_at DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

// Export functions
function exportToCSV($data, $headers, $filename) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
    $output = fopen('php://output', 'w');
    fputcsv($output, $headers);
    foreach ($data as $row) {
        fputcsv($output, $row);
    }
    fclose($output);
    exit;
}

if (isset($_GET['export']) && $_GET['export'] === 'orders') {
    $orders = $pdo->query("SELECT id, order_date, total_amount, status, shipping_address, u.username 
                          FROM orders o JOIN users u ON o.user_id = u.id")->fetchAll(PDO::FETCH_ASSOC);
    exportToCSV($orders, ['ID', 'Order Date', 'Total Amount', 'Status', 'Shipping Address', 'Customer'], 'orders');
} elseif (isset($_GET['export']) && $_GET['export'] === 'users') {
    $users = $pdo->query("SELECT id, username, email, profile_picture FROM users WHERE role = 'customer'")->fetchAll(PDO::FETCH_ASSOC);
    exportToCSV($users, ['ID', 'Username', 'Email', 'Profile Picture'], 'users');
} elseif (isset($_GET['export']) && $_GET['export'] === 'products') {
    $products = $pdo->query("SELECT id, product_name, price, category, description, stock, rating FROM products")->fetchAll(PDO::FETCH_ASSOC);
    exportToCSV($products, ['ID', 'Product Name', 'Price', 'Category', 'Description', 'Stock', 'Rating'], 'products');
}

// Reset database function
if (isset($_POST['reset_database']) && $_SESSION['role'] === 'admin') {
    if (isset($_POST['confirm_reset']) && $_POST['confirm_reset'] === 'yes') {
        $admin_id = 1; // Change this if your admin has a different ID
        $pdo->beginTransaction();
        try {
            $pdo->exec("TRUNCATE TABLE cart");
            $pdo->exec("TRUNCATE TABLE wishlist");
            $pdo->exec("TRUNCATE TABLE order_items");
            $pdo->exec("TRUNCATE TABLE orders");
            $stmt = $pdo->prepare("DELETE FROM users WHERE id != ? AND role = 'customer'");
            $stmt->execute([$admin_id]);
            $pdo->exec("TRUNCATE TABLE products");
            $pdo->exec("ALTER TABLE cart AUTO_INCREMENT = 1");
            $pdo->exec("ALTER TABLE wishlist AUTO_INCREMENT = 1");
            $pdo->exec("ALTER TABLE order_items AUTO_INCREMENT = 1");
            $pdo->exec("ALTER TABLE orders AUTO_INCREMENT = 1");
            $pdo->exec("ALTER TABLE products AUTO_INCREMENT = 1");
            $pdo->commit();
            header("Location: dashboard.php?reset=success");
            exit;
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = "Database reset failed: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Dill Ruu Fashion</title>
    <link rel="stylesheet" href="../styles.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <nav class="admin-navbar">
        <div class="logo">Dill Ruu Fashion Admin</div>
        <ul class="nav-links" id="admin-nav-links">
            <li><a href="dashboard.php" class="nav-link">Dashboard</a></li>
            <li><a href="products.php" class="nav-link">Products</a></li>
            <li><a href="orders.php" class="nav-link">Orders</a></li>
            <li><a href="users.php" class="nav-link">Users</a></li>
            <li><a href="../logout.php" class="nav-link logout">Logout <i class="fas fa-sign-out-alt"></i></a></li>
        </ul>
        <div class="menu-toggle" id="admin-mobile-menu">
            <span class="bar"></span>
            <span class="bar"></span>
            <span class="bar"></span>
        </div>
    </nav>

    <section class="dashboard-section">
        <h2 class="section-title">Admin Dashboard</h2>

        <!-- Export and Reset Buttons -->
        <div class="export-controls">
            <a href="?export=orders" class="admin-btn export-btn"><i class="fas fa-download"></i> Export Orders</a>
            <a href="?export=users" class="admin-btn export-btn"><i class="fas fa-download"></i> Export Users</a>
            <a href="?export=products" class="admin-btn export-btn"><i class="fas fa-download"></i> Export Products</a>
            <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to reset the database? This will delete all data except the admin account. Backup first!');">
                <input type="hidden" name="confirm_reset" value="yes">
                <button type="submit" name="reset_database" class="admin-btn reset-btn"><i class="fas fa-redo"></i> Reset Database</button>
            </form>
        </div>
        <?php if (isset($_GET['reset']) && $_GET['reset'] === 'success'): ?>
            <p class="success-message">Database reset successfully!</p>
        <?php endif; ?>
        <?php if (isset($error)): ?>
            <p class="auth-error"><?php echo $error; ?></p>
        <?php endif; ?>

        <!-- Analytics Overview -->
        <div class="analytics-overview">
            <div class="analytics-card">
                <h3>Total Revenue</h3>
                <p class="analytics-value">Rs.<?php echo number_format($total_revenue, 2); ?></p>
            </div>
            <div class="analytics-card">
                <h3>Average Order Value</h3>
                <p class="analytics-value">Rs.<?php echo number_format($avg_order_value, 2); ?></p>
            </div>
            <div class="analytics-card">
                <h3>Returning Customers</h3>
                <p class="analytics-value"><?php echo number_format($returning_percentage, 1); ?>%</p>
            </div>
            <div class="analytics-card">
                <h3>Top Category</h3>
                <p class="analytics-value"><?php echo $top_category; ?></p>
            </div>
        </div>

        <!-- Charts -->
        <div class="charts-container">
            <div class="chart-card">
                <h3 class="chart-title">Sales Trend (Last 30 Days)</h3>
                <canvas id="salesChart"></canvas>
            </div>
            <div class="chart-card">
                <h3 class="chart-title">User Growth (Last 30 Days)</h3>
                <canvas id="userGrowthChart"></canvas>
            </div>
            <div class="chart-card">
                <h3 class="chart-title">Product Distribution</h3>
                <canvas id="categoryChart"></canvas>
            </div>
        </div>

        <div class="dashboard-grid">
            <div class="dashboard-card" style="animation-delay: 0s;">
                <i class="fas fa-box fa-2x" style="color: #fa255e;"></i>
                <h3>Products</h3>
                <p><?php echo $product_count; ?> Total</p>
                <a href="products.php" class="dashboard-link">Manage Products</a>
            </div>
            <div class="dashboard-card" style="animation-delay: 0.2s;">
                <i class="fas fa-shopping-cart fa-2x" style="color: #fa255e;"></i>
                <h3>Orders</h3>
                <p><?php echo $order_count; ?> Total</p>
                <a href="orders.php" class="dashboard-link">Manage Orders</a>
            </div>
            <div class="dashboard-card" style="animation-delay: 0.4s;">
                <i class="fas fa-users fa-2x" style="color: #fa255e;"></i>
                <h3>Customers</h3>
                <p><?php echo $user_count; ?> Total</p>
                <a href="users.php" class="dashboard-link">Manage Users</a>
            </div>
        </div>

        <div class="recent-activity">
            <h3 class="section-subtitle">Recent Activity</h3>
            <div class="activity-grid">
                <div class="activity-card">
                    <h4>Recent Products</h4>
                    <ul class="activity-list">
                        <?php foreach ($recent_products as $product): ?>
                            <li><?php echo htmlspecialchars($product['product_name']); ?> - Rs.<?php echo number_format($product['price'], 2); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="activity-card">
                    <h4>Recent Orders</h4>
                    <ul class="activity-list">
                        <?php foreach ($recent_orders as $order): ?>
                            <li>Order #<?php echo $order['id']; ?> - Rs.<?php echo number_format($order['total_amount'], 2); ?> (<span class="order-status <?php echo $order['status']; ?>"><?php echo ucfirst($order['status']); ?></span>)</li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="activity-card">
                    <h4>Top Selling Products</h4>
                    <ul class="activity-list">
                        <?php foreach ($top_products as $product): ?>
                            <li><?php echo htmlspecialchars($product['product_name']); ?> - Sold: <?php echo $product['total_sold']; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <script src="../script.js"></script>
    <script>
        // Chart.js Initialization
        document.addEventListener('DOMContentLoaded', () => {
            const salesCtx = document.getElementById('salesChart').getContext('2d');
            new Chart(salesCtx, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode(array_column($sales_data, 'date')); ?>,
                    datasets: [{
                        label: 'Total Sales (Rs.)',
                        data: <?php echo json_encode(array_column($sales_data, 'total')); ?>,
                        borderColor: '#fa255e',
                        backgroundColor: 'rgba(250, 37, 94, 0.2)',
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: { y: { beginAtZero: true } },
                    plugins: { legend: { labels: { color: '#000000' } }, tooltip: { backgroundColor: '#ffffff', titleColor: '#000000', bodyColor: '#c39ea0' } },
                    animation: { duration: 1000, easing: 'easeInOutQuad' }
                }
            });

            const userGrowthCtx = document.getElementById('userGrowthChart').getContext('2d');
            new Chart(userGrowthCtx, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode(array_column($user_growth, 'date')); ?>,
                    datasets: [{
                        label: 'New Users',
                        data: <?php echo json_encode(array_column($user_growth, 'count')); ?>,
                        backgroundColor: '#c39ea0',
                        borderColor: '#fa255e',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: { y: { beginAtZero: true } },
                    plugins: { legend: { labels: { color: '#000000' } }, tooltip: { backgroundColor: '#ffffff', titleColor: '#000000', bodyColor: '#c39ea0' } },
                    animation: { duration: 1000, easing: 'easeInOutQuad' }
                }
            });

            const categoryCtx = document.getElementById('categoryChart').getContext('2d');
            new Chart(categoryCtx, {
                type: 'pie',
                data: {
                    labels: <?php echo json_encode(array_column($category_distribution, 'category')); ?>,
                    datasets: [{
                        data: <?php echo json_encode(array_column($category_distribution, 'count')); ?>,
                        backgroundColor: ['#fa255e', '#c39ea0', '#f8e5e5', '#000000'],
                        borderColor: '#ffffff',
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { labels: { color: '#000000' } }, tooltip: { backgroundColor: '#ffffff', titleColor: '#000000', bodyColor: '#c39ea0' } },
                    animation: { duration: 1000, easing: 'easeInOutQuad' }
                }
            });
        });

        // Real-Time Updates
        function updateDashboard() {
            showLoading();
            fetch('dashboard.php?update=1', {
                method: 'GET',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            })
            .then(response => response.json())
            .then(data => {
                hideLoading();
                document.querySelector('.dashboard-card:nth-child(1) p').textContent = data.product_count;
                document.querySelector('.dashboard-card:nth-child(2) p').textContent = data.order_count;
                document.querySelector('.dashboard-card:nth-child(3) p').textContent = data.user_count;
                document.querySelector('.analytics-value:nth-child(1)').textContent = 'Rs.' + numberFormat(data.total_revenue, 2);
                document.querySelector('.analytics-value:nth-child(2)').textContent = 'Rs.' + numberFormat(data.avg_order_value, 2);
                document.querySelector('.analytics-value:nth-child(3)').textContent = numberFormat(data.returning_percentage, 1) + '%';
                document.querySelector('.activity-list:nth-child(2)').innerHTML = data.recent_orders.map(order => `<li>Order #${order.id} - Rs.${numberFormat(order.total_amount, 2)} (<span class="order-status ${order.status}">${ucfirst(order.status)}</span>)</li>`).join('');
                document.querySelector('.activity-list:nth-child(3)').innerHTML = data.top_products.map(product => `<li>${product.product_name} - Sold: ${product.total_sold}</li>`).join('');
                const indicator = document.createElement('div');
                indicator.className = 'real-time-indicator';
                indicator.textContent = 'Updated just now';
                document.querySelector('.recent-activity').appendChild(indicator);
                setTimeout(() => indicator.remove(), 2000);
            })
            .catch(error => {
                hideLoading();
                console.error('Error updating dashboard:', error);
            });
        }

        setInterval(updateDashboard, 30000); // Update every 30 seconds
        updateDashboard(); // Initial update
    </script>
</body>
</html>